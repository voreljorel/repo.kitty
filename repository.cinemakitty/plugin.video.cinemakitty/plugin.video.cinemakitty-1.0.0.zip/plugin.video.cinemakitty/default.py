import xbmcaddon
import xbmcgui
import xbmcplugin
import hashlib
import xbmc
import ftplib
import xbmcvfs
import sqlite3
import zipfile
import shutil
import os
import re
import sys
import os
import re
import ftplib
import zipfile
import ftplib
import zipfile
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET

from hashlib import sha1

addon = xbmcaddon.Addon()
addon_handle = int(sys.argv[1])
token = None

def log_message(message, level=xbmc.LOGINFO):
    xbmc.log(f"[CinemaKitty] {message}", level=level)

def get_credentials():
    username = addon.getSetting("username")
    password = addon.getSetting("password")
    return username, password

def fetch_salt(username):
    data = urllib.parse.urlencode({"username_or_email": username}).encode("utf-8")
    req = urllib.request.Request("https://webshare.cz/api/salt/", data=data)
    with urllib.request.urlopen(req) as res:
        xml = res.read().decode("utf-8")
        return ET.fromstring(xml).find("salt").text

def md5crypt(password, salt, magic='$1$'):
    password = password.encode('utf-8')
    salt = salt.encode('utf-8')
    magic = magic.encode('utf-8')
    m = hashlib.md5()
    m.update(password + magic + salt)
    mixin = hashlib.md5(password + salt + password).digest()
    for i in range(len(password)):
        m.update(mixin[i % 16:i % 16+1])
    i = len(password)
    while i:
        if i & 1:
            m.update(b'\x00')
        else:
            m.update(password[:1])
        i >>= 1
    final = m.digest()
    for i in range(1000):
        m2 = hashlib.md5()
        if i & 1:
            m2.update(password)
        else:
            m2.update(final)
        if i % 3:
            m2.update(salt)
        if i % 7:
            m2.update(password)
        if i & 1:
            m2.update(final)
        else:
            m2.update(password)
        final = m2.digest()
    def to64(v, n):
        itoa64 = "./0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"
        ret = ""
        while n > 0:
            ret += itoa64[v & 0x3f]
            v >>= 6
            n -= 1
        return ret
    l = [c for c in final]
    return (magic.decode('utf-8') + salt.decode('utf-8') + '$' +
        to64((l[0] << 16) | (l[6] << 8) | l[12], 4) +
        to64((l[1] << 16) | (l[7] << 8) | l[13], 4) +
        to64((l[2] << 16) | (l[8] << 8) | l[14], 4) +
        to64((l[3] << 16) | (l[9] << 8) | l[15], 4) +
        to64((l[4] << 16) | (l[10] << 8) | l[5], 4) +
        to64(l[11], 2))

def compute_digest_and_hash(username, password, salt):
    crypt = md5crypt(password, salt)
    password_hash = sha1(crypt.encode("utf-8")).hexdigest()
    digest = hashlib.md5((username + ":Webshare:" + password_hash).encode("utf-8")).hexdigest()
    return digest, password_hash


def perform_login(username, digest, password_hash):
    data = urllib.parse.urlencode({
        "username_or_email": username,
        "password": password_hash,     # SHA1(MD5_CRYPT)
        "digest": digest,              # MD5(user:Webshare:password_hash)
        "keep_logged_in": 1,
        "wst": "KodiGeneratedWST"
    }).encode("utf-8")

    req = urllib.request.Request("https://webshare.cz/api/login/", data=data)
    with urllib.request.urlopen(req) as res:
        xml = res.read().decode("utf-8")
        return ET.fromstring(xml), xml


def verify_login():
    username, password = get_credentials()
    if not username or not password:
        xbmcgui.Dialog().notification("CinemaKitty", "Zadej přihlašovací údaje v nastavení.", xbmcgui.NOTIFICATION_ERROR)
        return None

    try:
        salt = fetch_salt(username)
        digest, password_hash = compute_digest_and_hash(username, password, salt)
        response, raw_xml = perform_login(username, digest, password_hash)
        token = response.findtext("token")

        if not token:
            error_message = response.findtext("message") or "Neznámá chyba"
            xbmcgui.Dialog().notification("CinemaKitty", f"Přihlášení selhalo: {error_message}", xbmcgui.NOTIFICATION_ERROR)
            return None

        return token

    except Exception as e:
        log_message(f"Chyba během přihlášení: {str(e)}", level=xbmc.LOGERROR)
        xbmcgui.Dialog().notification("CinemaKitty", f"Chyba: {str(e)}", xbmcgui.NOTIFICATION_ERROR)
        return None


def show_main_menu(token):
    items = []

    li = xbmcgui.ListItem(label="Dnešní tipy (ČSFD)")
    li.setArt({
        "icon": "https://img.icons8.com/color/48/star.png",
        "thumb": "https://img.icons8.com/color/48/star.png"
    })
    url = f"{sys.argv[0]}?action=csfd_tips"
    items.append((url, li, True))

    li = xbmcgui.ListItem(label="Filmy")
    li.setArt({
        "icon": "https://img.icons8.com/color/48/clapperboard.png",
        "thumb": "https://img.icons8.com/color/48/clapperboard.png"
    })
    url = f"{sys.argv[0]}?action=movies"
    items.append((url, li, True))

    li = xbmcgui.ListItem(label="Seriály")
    li.setArt({
        "icon": "https://img.icons8.com/color/48/tv-show.png",
        "thumb": "https://img.icons8.com/color/48/tv-show.png"
    })
    url = f"{sys.argv[0]}?action=series"
    items.append((url, li, True))

    li = xbmcgui.ListItem(label="Vyhledávání filmů")
    li.setArt({
        "icon": "https://img.icons8.com/color/48/search.png",
        "thumb": "https://img.icons8.com/color/48/search.png"
    })
    url = f"{sys.argv[0]}?action=search"
    items.append((url, li, True))

    for url, li, isFolder in items:
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=isFolder)
    xbmcplugin.endOfDirectory(addon_handle)


def check_for_update():
    addon_id = "plugin.video.cinemakitty"
    addon_path = xbmcvfs.translatePath(f"special://home/addons/{addon_id}")
    addon_xml = os.path.join(addon_path, "addon.xml")

    def extract_version(fname):
        match = re.search(r'_(\d+\.\d+\.\d+)\.zip', fname)
        return match.group(1) if match else None

    # 1. Zjisti aktuální verzi doplňku
    try:
        with open(addon_xml, encoding="utf-8") as f:
            content = f.read()
        local_version = re.search(r'version="([\d\.]+)"', content).group(1)
    except Exception as e:
        xbmcgui.Dialog().notification("CinemaKitty", f"Nelze načíst verzi: {e}", xbmcgui.NOTIFICATION_ERROR)
        return

    # 2. Připoj se k FTP a najdi novější ZIP
    try:
        ftp = ftplib.FTP("ftpupload.net")
        ftp.login("if0_38861367", "7abNicfDM40Dars")
        ftp.cwd("htdocs")
        files = ftp.nlst()
        zips = [f for f in files if f.startswith(f"{addon_id}-") and f.endswith(".zip")]

        zips_versions = [(extract_version(f), f) for f in zips if extract_version(f)]
        zips_versions.sort(key=lambda x: list(map(int, x[0].split('.'))), reverse=True)

        if not zips_versions:
            return

        latest_version, latest_file = zips_versions[0]
        if latest_version <= local_version:
            return  # aktuální verze

        # 3. Stáhni ZIP do složky packages
        packages_path = xbmcvfs.translatePath("special://home/addons/packages/")
        zip_local = os.path.join(packages_path, latest_file)

        with open(zip_local, "wb") as f:
            ftp.retrbinary(f"RETR " + latest_file, f.write)
        ftp.quit()

        # 4. Instalace pomocí Kodi (bez přímého rozbalování)
        xbmc.executebuiltin(f'InstallAddon("{zip_local}")')
        xbmcgui.Dialog().notification("CinemaKitty", f"Aktualizace na {latest_version} připravena. Restart Kodi.", xbmcgui.NOTIFICATION_INFO)

    except Exception as e:
        xbmcgui.Dialog().notification("CinemaKitty", f"Chyba při aktualizaci: {e}", xbmcgui.NOTIFICATION_ERROR)


def list_movies_from_ftp(page=1):

    local_db_path = xbmcvfs.translatePath("special://temp/cinemakitty.db")
    page_size = 20
    offset = (page - 1) * page_size

    try:
        ftp = ftplib.FTP("ftpupload.net")
        ftp.login("if0_38861367", "7abNicfDM40Dars")
        ftp.cwd("htdocs")
        with open(local_db_path, "wb") as f:
            ftp.retrbinary("RETR cinemakitty.db", f.write)
        ftp.quit()
    except Exception as e:
        xbmcgui.Dialog().notification("CinemaKitty", f"Chyba FTP: {e}", xbmcgui.NOTIFICATION_ERROR)
        return

    try:
        conn = sqlite3.connect(local_db_path)
        cursor = conn.cursor()
        cursor.execute("""
            SELECT Title, WebshareIdent, PosterPath, Overview
            FROM Movies
            WHERE WebshareIdent IS NOT NULL AND WebshareIdent != ''
            ORDER BY Id DESC
            LIMIT ? OFFSET ?
        """, (page_size, offset))
        rows = cursor.fetchall()
        conn.close()

        if not rows:
            xbmcgui.Dialog().notification("CinemaKitty", "Žádné další filmy.", xbmcgui.NOTIFICATION_INFO)
            return

        for title, ident, poster_path, overview in rows:
            try:
                stream_url = get_direct_link(token, ident)
                poster_url = f"https://image.tmdb.org/t/p/w500{poster_path}" if poster_path else ""
                li = xbmcgui.ListItem(label=title)
                li.setArt({"poster": poster_url, "thumb": poster_url})
                li.setProperty("IsPlayable", "true")

                info = li.getVideoInfoTag()
                info.setTitle(title)
                info.setPlot(overview)

                xbmcplugin.addDirectoryItem(handle=addon_handle, url=stream_url, listitem=li, isFolder=False)
            except Exception as e:
                log_message(f"Přeskočen '{title}' kvůli chybě: {e}")

        # přidání odkazu na další stránku
        next_page_url = f"{sys.argv[0]}?action=movies&page={page + 1}"
        li = xbmcgui.ListItem(label="Další stránka")
        li.setArt({
            "icon": "https://img.icons8.com/color/48/chevron-right.png",
            "thumb": "https://img.icons8.com/color/48/chevron-right.png"
        })

        xbmcplugin.addDirectoryItem(handle=addon_handle, url=next_page_url, listitem=li, isFolder=True)

        xbmcplugin.endOfDirectory(addon_handle)

    except Exception as e:
        log_message(f"Chyba při čtení DB: {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification("CinemaKitty", f"Chyba DB: {e}", xbmcgui.NOTIFICATION_ERROR)

def list_series_from_ftp():

    local_db_path = xbmcvfs.translatePath("special://temp/cinemakitty.db")

    try:
        ftp = ftplib.FTP("ftpupload.net")
        ftp.login("if0_38861367", "7abNicfDM40Dars")
        ftp.cwd("htdocs")
        with open(local_db_path, "wb") as f:
            ftp.retrbinary("RETR cinemakitty.db", f.write)
        ftp.quit()
    except Exception as e:
        xbmcgui.Dialog().notification("CinemaKitty", f"Chyba FTP: {e}", xbmcgui.NOTIFICATION_ERROR)
        return

    try:
        conn = sqlite3.connect(local_db_path)
        cursor = conn.cursor()
        cursor.execute("SELECT Id, Title, PosterPath, Overview FROM Series")
        rows = cursor.fetchall()
        conn.close()

        if not rows:
            xbmcgui.Dialog().notification("CinemaKitty", "V databázi nejsou žádné seriály.", xbmcgui.NOTIFICATION_INFO)
            return

        for series_id, title, poster_path, overview in rows:
            url = f"{sys.argv[0]}?action=episodes&series_id={series_id}"
            poster_url = f"https://image.tmdb.org/t/p/w500{poster_path}" if poster_path else ""
            li = xbmcgui.ListItem(label=title)
            li.setArt({"poster": poster_url, "thumb": poster_url})

            info = li.getVideoInfoTag()
            info.setTitle(title)
            info.setPlot(overview)

            xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)

        xbmcplugin.endOfDirectory(addon_handle)

    except Exception as e:
        log_message(f"Chyba při čtení Series: {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification("CinemaKitty", f"Chyba DB: {e}", xbmcgui.NOTIFICATION_ERROR)


def list_episodes_from_ftp():
    local_db_path = xbmcvfs.translatePath("special://temp/cinemakitty.db")

    try:
        ftp = ftplib.FTP("ftpupload.net")
        ftp.login("if0_38861367", "7abNicfDM40Dars")
        ftp.cwd("htdocs")
        with open(local_db_path, "wb") as f:
            ftp.retrbinary("RETR cinemakitty.db", f.write)
        ftp.quit()
    except Exception as e:
        xbmcgui.Dialog().notification("CinemaKitty", f"Chyba FTP: {e}", xbmcgui.NOTIFICATION_ERROR)
        return

    try:
        conn = sqlite3.connect(local_db_path)
        cursor = conn.cursor()
        cursor.execute("""
            SELECT s.Title, e.Title, e.WebshareIdent, e.PosterPath
            FROM Episodes e
            JOIN Series s ON e.SeriesId = s.Id
            WHERE e.WebshareIdent IS NOT NULL AND e.WebshareIdent != ''
        """)
        rows = cursor.fetchall()
        conn.close()

        if not rows:
            xbmcgui.Dialog().notification("CinemaKitty", "V databázi nejsou žádné epizody.", xbmcgui.NOTIFICATION_INFO)
            return

        for series_title, episode_title, ident, poster_path in rows:
            try:
                stream_url = get_direct_link(token, ident)
                poster_url = f"https://image.tmdb.org/t/p/w500{poster_path}" if poster_path else ""
                full_title = f"{series_title} – {episode_title}"
                li = xbmcgui.ListItem(label=full_title)
                li.setArt({"poster": poster_url, "thumb": poster_url})
                li.setProperty("IsPlayable", "true")
                xbmcplugin.addDirectoryItem(handle=addon_handle, url=stream_url, listitem=li, isFolder=False)
            except Exception as e:
                log_message(f"Přeskočena epizoda '{series_title} - {episode_title}' kvůli chybě: {e}")

        xbmcplugin.endOfDirectory(addon_handle)

    except Exception as e:
        log_message(f"Chyba při čtení DB: {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification("CinemaKitty", f"Chyba DB: {e}", xbmcgui.NOTIFICATION_ERROR)

def list_episodes_by_series(series_id):

    local_db_path = xbmcvfs.translatePath("special://temp/cinemakitty.db")

    try:
        conn = sqlite3.connect(local_db_path)
        cursor = conn.cursor()
        cursor.execute("""
            SELECT s.Title, e.Title, e.WebshareIdent, e.PosterPath, e.Overview
            FROM Episodes e
            JOIN Series s ON e.SeriesId = s.Id
            WHERE e.WebshareIdent IS NOT NULL AND e.WebshareIdent != ''
              AND s.Id = ?
        """, (series_id,))
        rows = cursor.fetchall()
        conn.close()

        if not rows:
            xbmcgui.Dialog().notification("CinemaKitty", "Tento seriál nemá žádné epizody.", xbmcgui.NOTIFICATION_INFO)
            return

        for series_title, episode_title, ident, poster_path, overview in rows:
            try:
                stream_url = get_direct_link(token, ident)
                poster_url = f"https://image.tmdb.org/t/p/w500{poster_path}" if poster_path else ""
                full_title = episode_title
                li = xbmcgui.ListItem(label=full_title)
                li.setArt({"poster": poster_url, "thumb": poster_url})
                li.setProperty("IsPlayable", "true")
                li.setInfo("video", {
                    "title": episode_title,
                    "plot": overview
                })
                xbmcplugin.addDirectoryItem(handle=addon_handle, url=stream_url, listitem=li, isFolder=False)
            except Exception as e:
                log_message(f"Přeskočena epizoda '{episode_title}' kvůli chybě: {e}")

        xbmcplugin.endOfDirectory(addon_handle)

    except Exception as e:
        log_message(f"Chyba při čtení Episodes: {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification("CinemaKitty", f"Chyba DB: {e}", xbmcgui.NOTIFICATION_ERROR)

def list_seasons_by_series(series_id):
    local_db_path = xbmcvfs.translatePath("special://temp/cinemakitty.db")

    try:
        conn = sqlite3.connect(local_db_path)
        cursor = conn.cursor()
        cursor.execute("""
            SELECT SeasonNumber, MAX(PosterPath)
            FROM Episodes
            WHERE SeriesId = ?
            GROUP BY SeasonNumber
            ORDER BY SeasonNumber
        """, (series_id,))
        seasons = cursor.fetchall()
        conn.close()

        if not seasons:
            xbmcgui.Dialog().notification("CinemaKitty", "Žádné sezóny nenalezeny.", xbmcgui.NOTIFICATION_INFO)
            return

        for season_number, poster_path in seasons:
            label = f"Sezóna {season_number}"
            url = f"{sys.argv[0]}?action=season&series_id={series_id}&season={season_number}"
            poster_url = f"https://image.tmdb.org/t/p/w500{poster_path}" if poster_path else ""
            li = xbmcgui.ListItem(label=label)
            li.setArt({"poster": poster_url, "thumb": poster_url})
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=True)

        xbmcplugin.endOfDirectory(addon_handle)

    except Exception as e:
        log_message(f"Chyba při čtení sezón: {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification("CinemaKitty", f"Chyba DB: {e}", xbmcgui.NOTIFICATION_ERROR)


def list_episodes_by_season(series_id, season_number):

    local_db_path = xbmcvfs.translatePath("special://temp/cinemakitty.db")

    try:
        conn = sqlite3.connect(local_db_path)
        cursor = conn.cursor()
        cursor.execute("""
            SELECT e.Title, e.WebshareIdent, e.PosterPath, e.Overview
            FROM Episodes e
            WHERE e.SeriesId = ? AND e.SeasonNumber = ? AND e.WebshareIdent IS NOT NULL AND e.WebshareIdent != ''
            ORDER BY e.EpisodeNumber
        """, (series_id, season_number))
        rows = cursor.fetchall()
        conn.close()

        if not rows:
            xbmcgui.Dialog().notification("CinemaKitty", "Tato sezóna nemá žádné epizody.", xbmcgui.NOTIFICATION_INFO)
            return

        for title, ident, poster_path, overview in rows:
            try:
                stream_url = get_direct_link(token, ident)
                poster_url = f"https://image.tmdb.org/t/p/w500{poster_path}" if poster_path else ""
                li = xbmcgui.ListItem(label=title)
                li.setArt({"poster": poster_url, "thumb": poster_url})
                li.setProperty("IsPlayable", "true")
                li.setInfo("video", {
                    "title": title,
                    "plot": overview
                })
                xbmcplugin.addDirectoryItem(handle=addon_handle, url=stream_url, listitem=li, isFolder=False)
            except Exception as e:
                log_message(f"Přeskočena epizoda '{title}' kvůli chybě: {e}")

        xbmcplugin.endOfDirectory(addon_handle)

    except Exception as e:
        log_message(f"Chyba při čtení epizod: {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification("CinemaKitty", f"Chyba DB: {e}", xbmcgui.NOTIFICATION_ERROR)


def handle_csfd_tips(token):
    import re
    from html import unescape

    try:
        req = urllib.request.Request("https://www.csfd.cz/televize/")
        req.add_header("User-Agent", "Mozilla/5.0")

        with urllib.request.urlopen(req) as res:
            html = res.read().decode("utf-8")

        articles = re.findall(r'<article class="article article-poster-78">(.*?)</article>', html, re.DOTALL)
        tips = []

        for article in articles:
            title_match = re.search(r'<a href="(/film/\d+[^"]+)"[^>]*class="film-title-name">([^<]+)</a>', article)
            year_match = re.search(r'<span class="info">\((\d{4})\)</span>', article)
            orig_match = re.search(r'<p class="film-origins-genres"><span class="info">([^<]+)</span>', article)
            srcset_match = re.search(r'<img[^>]+srcset="([^"]+)"', article)
            plot_match = re.search(r'<p class="p-tvtips-2row.*?">(.*?)</p>', article, re.DOTALL)

            if title_match and srcset_match:
                cz_title = unescape(title_match.group(2)).strip()
                year = year_match.group(1) if year_match else ""

                orig_title = ""
                if orig_match:
                    orig_parts = orig_match.group(1).split(",")
                    if len(orig_parts) > 1:
                        orig_title = orig_parts[0].strip()

                srcset = srcset_match.group(1)
                largest = srcset.split(",")[-1].split()[0].strip()
                poster_url = "https:" + largest if largest.startswith("//") else ""

                plot = re.sub(r'<.*?>', '', plot_match.group(1)).replace("&nbsp;", " ").strip() if plot_match else ""

                tips.append((cz_title, orig_title, poster_url, plot, year))

        if not tips:
            xbmcgui.Dialog().notification("CinemaKitty", "Žádné tipy nebyly nalezeny.", xbmcgui.NOTIFICATION_INFO)
            return

        for cz_title, orig_title, poster_url, overview, year in tips:
            label = f"{cz_title} ({year})" if year else cz_title
            url = f"{sys.argv[0]}?action=autoplay&title={urllib.parse.quote(cz_title)}&alt={urllib.parse.quote(orig_title)}"
            li = xbmcgui.ListItem(label=label)
            li.setArt({"thumb": poster_url, "poster": poster_url})

            info = li.getVideoInfoTag()
            info.setTitle(cz_title)
            info.setPlot(overview)
            if year:
                info.setYear(int(year))

            context = [
                ("Vyhledat na Webshare", f"RunPlugin({sys.argv[0]}?action=search_webshare&query={urllib.parse.quote(cz_title)})")
            ]
            li.addContextMenuItems(context)
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=url, listitem=li, isFolder=False)

        xbmcplugin.endOfDirectory(addon_handle)

    except Exception as e:
        log_message(f"Chyba v handle_csfd_tips: {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification("CinemaKitty", f"Chyba při načítání tipů: {e}", xbmcgui.NOTIFICATION_ERROR)


def search_webshare(token, query, sort="rating", category="video", limit=100, offset=0, require_1080p=False, require_cz_audio=False, relaxed=False):
    VIDEO_EXT = (".mp4", ".mkv", ".avi")
    MIN_SIZE = 100 * 1024 * 1024 if relaxed else 300 * 1024 * 1024
    BAD_KEYWORDS = [] if relaxed else ["camrip", "ts", "telesync", "screener", "sample"]
    EXCLUDE_EXTS = [] if relaxed else [".part", ".rar", ".srt", ".nfo", ".txt", ".exe"]

    params = urllib.parse.urlencode({
        "what": query,
        "sort": sort,
        "limit": limit,
        "offset": offset,
        "category": category
    }).encode("utf-8")

    req = urllib.request.Request("https://webshare.cz/api/search/", data=params)
    req.add_header("User-Agent", "Mozilla/5.0")
    req.add_header("Cookie", f"session={token}")
    req.add_header("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8")

    with urllib.request.urlopen(req) as res:
        xml = res.read().decode("utf-8")
        root = ET.fromstring(xml)

    results = []
    seen = set()

    for file in root.findall(".//file"):
        name = file.findtext("name")
        size = file.findtext("size")
        if not name or not size:
            continue

        name_lower = name.lower()

        if not relaxed and not name_lower.endswith(VIDEO_EXT):
            continue
        if any(ext in name_lower for ext in EXCLUDE_EXTS):
            continue
        if any(bad in name_lower for bad in BAD_KEYWORDS):
            continue
        if int(size) < MIN_SIZE:
            continue
        if name_lower in seen:
            continue
        if require_1080p and "1080p" not in name_lower:
            continue
        if require_cz_audio and not any(k in name_lower for k in ["cz", "dabing"]):
            continue

        seen.add(name_lower)

        ident = file.findtext("ident")
        rating = file.findtext("positive_votes") or "0"

        results.append({
            "name": name,
            "size": int(size),
            "ident": ident,
            "rating": int(rating)
        })

    results.sort(key=lambda x: x["size"], reverse=True)
    return results

def get_direct_link(token, ident, download_type="video_stream"):
    data = urllib.parse.urlencode({
        "ident": ident,
        "download_type": download_type,
        "wst": token,  # ← Tohle je klíčové!
        "device_uuid": "cinemakitty",
        "device_vendor": "CinemaKitty",
        "device_model": "KodiAddon",
        "device_res_x": 1920,
        "device_res_y": 1080,
        "force_https": 1
    }).encode("utf-8")


    req = urllib.request.Request("https://webshare.cz/api/file_link/", data=data)
    req.add_header("User-Agent", "Mozilla/5.0")
    req.add_header("Cookie", f"session={token}; wst=KodiGeneratedWST")  # <- přidáno!
    req.add_header("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8")

    with urllib.request.urlopen(req) as res:
        xml = res.read().decode("utf-8")
        root = ET.fromstring(xml)

    if root.findtext("status") != "OK":
        raise Exception("Nepodařilo se získat přímý odkaz.")

    return root.findtext("link")


def is_vip(token):
    try:
        test_ident = "QMTJ4UGZkB"  # můžeš změnit na libovolný známý VIP-only ident
        data = urllib.parse.urlencode({
            "ident": test_ident,
            "download_type": "video_stream",
            "device_uuid": "cinemakitty",
            "device_vendor": "CinemaKitty",
            "device_model": "KodiAddon",
            "device_res_x": 1920,
            "device_res_y": 1080,
            "force_https": 1
        }).encode("utf-8")

        req = urllib.request.Request("https://webshare.cz/api/file_link/", data=data)
        req.add_header("User-Agent", "Mozilla/5.0")
        req.add_header("Cookie", f"session={token}")
        req.add_header("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8")

        with urllib.request.urlopen(req) as res:
            xml = res.read().decode("utf-8")
            root = ET.fromstring(xml)
            return root.findtext("status") == "OK"
    except Exception as e:
        log_message(f"Chyba při ověřování VIP přes file_link: {e}", xbmc.LOGERROR)
        return False


def run():
    global token
    check_for_update()  # 🆕 nejdříve zkontroluj aktualizaci

    handle = int(sys.argv[1])
    args = urllib.parse.parse_qs(sys.argv[2][1:])
    action = args.get("action", [None])[0]
    ident = args.get("ident", [None])[0]

    if not token:
        token = verify_login()
        if token:
            if not is_vip(token):
                xbmcgui.Dialog().notification("CinemaKitty", "Tento doplněk je pouze pro VIP účet!", xbmcgui.NOTIFICATION_ERROR)
                return
        else:
            return

    if action == "search":
        query = xbmcgui.Dialog().input("Zadej název filmu k vyhledání")
        if query:
            results = search_webshare(token, query)
            for result in results:
                try:
                    info = get_file_info(token, result["ident"])
                    size_mb = int(info["size"]) // (1024 * 1024)
                    label = f"{info['name']} ({size_mb} MB, {info['type'].upper()})"
                    li = xbmcgui.ListItem(label=label)
                    li.setInfo("video", {
                        "title": info["name"],
                        "genre": "Webshare",
                        "votes": int(info["positive_votes"]),
                        "plot": info["description"] or "",
                        "size": size_mb
                    })
                    url = f"{sys.argv[0]}?action=play&ident={result['ident']}"
                    xbmcplugin.addDirectoryItem(handle=handle, url=url, listitem=li, isFolder=False)
                except Exception as e:
                    log_message(f"Chyba při načtení informací o souboru: {e}")
            xbmcplugin.endOfDirectory(handle)

    elif action == "csfd_tips":
        handle_csfd_tips(token)

    elif action == "movies":
        page = int(args.get("page", [1])[0])
        list_movies_from_ftp(page)

    elif action == "series":
        list_series_from_ftp()

    elif action == "episodes":
        series_id = args.get("series_id", [None])[0]
        if series_id:
            list_seasons_by_series(series_id)

    elif action == "season":
        series_id = args.get("series_id", [None])[0]
        season = args.get("season", [None])[0]
        if series_id and season:
            list_episodes_by_season(series_id, int(season))

    elif action == "search_webshare":
        query = args.get("query", [None])[0]
        if query:
            results = search_webshare(token, query)
            if not results:
                xbmcgui.Dialog().notification("CinemaKitty", "Žádné výsledky.", xbmcgui.NOTIFICATION_INFO)
                return

            dialog_items = [f"{r['name']} ({r['size'] // (1024 * 1024)} MB)" for r in results[:50]]
            index = xbmcgui.Dialog().select("Vyber video", dialog_items)
            if index == -1:
                return

            selected = results[index]
            try:
                url = get_direct_link(token, selected["ident"])
                xbmc.Player().play(url)
            except Exception as e:
                xbmcgui.Dialog().notification("Chyba", str(e), xbmcgui.NOTIFICATION_ERROR)

    elif action == "play":
        if ident:
            try:
                url = get_direct_link(token, ident)
                xbmc.Player().play(url)
            except Exception as e:
                xbmcgui.Dialog().notification("Chyba při přehrávání", str(e), xbmcgui.NOTIFICATION_ERROR)


    elif action == "autoplay":
        import unicodedata
        import difflib

        def normalize(s):
            s = unicodedata.normalize("NFKD", s).encode("ASCII", "ignore").decode("utf-8").lower()
            s = s.replace("-", " ").replace("_", " ")
            return " ".join(s.split())

        def title_penalty(result, original_title):
            name = normalize(result["name"])
            orig = normalize(original_title)
            sequel_patterns = [
                " 2", " ii", " druhy", " 3", " iii", " třeti", " iv", "4", "5", "vi",
                "část 2", "cast 2", "s02", "e02", "season 2", "episode 2"
            ]
            for pattern in sequel_patterns:
                if pattern in name and pattern not in orig:
                    return -2
            return 0

        def quality_score(result):
            name = normalize(result["name"])
            size_mb = result["size"] // (1024 * 1024)
            ext_score = 1 if any(name.endswith(ext) for ext in [".mkv", ".mp4"]) else 0
            res_score = 0
            if "4k" in name or "2160p" in name:
                res_score = 3
            elif "1080p" in name:
                res_score = 2
            elif "720p" in name:
                res_score = 1
            elif size_mb > 2000:
                res_score = 2
            elif size_mb > 1000:
                res_score = 1
            lang_score = 1 if any(k in name for k in ["cz", "dabing", "cesky"]) else 0
            return res_score * 3 + ext_score * 2 + lang_score

        title = args.get("title", [None])[0] or ""
        alt_title = args.get("alt", [None])[0] or ""

        search_variants = [title, normalize(title)]
        if alt_title:
            search_variants += [alt_title, normalize(alt_title)]

        candidates = []
        for query in search_variants:
            for strict in [True, False]:
                results = search_webshare(token, query, require_1080p=strict, require_cz_audio=strict)
                for result in results:
                    result_name_norm = normalize(result["name"])
                    score = difflib.SequenceMatcher(None, normalize(query), result_name_norm).ratio()
                    candidates.append((score, result, query))

        scored_candidates = []
        seen_idents = set()  # nová sada pro kontrolu duplicit

        for score, result, query in candidates:
            if score >= 0.6 and result["ident"] not in seen_idents:
                q_score = quality_score(result) + title_penalty(result, query)
                scored_candidates.append((q_score, score, result))
                seen_idents.add(result["ident"])


        for q_score, score, result in scored_candidates:
            log_message(f"Kandidát: {result['name']} | podobnost: {score:.2f} | kvalita: {q_score}")

        scored_candidates.sort(key=lambda x: (x[0], x[1]), reverse=True)

        if not scored_candidates:
            xbmcgui.Dialog().notification("CinemaKitty", "Nenalezen kvalitní výsledek.", xbmcgui.NOTIFICATION_INFO)
            return

        try:
            if not scored_candidates or scored_candidates[0][0] < 5:
                dialog_items = [f"{c[2]['name']} ({c[2]['size'] // (1024 * 1024)} MB)" for c in scored_candidates[:10]]
                if not dialog_items:
                    xbmcgui.Dialog().notification("CinemaKitty", "Žádné vhodné výsledky k výběru.", xbmcgui.NOTIFICATION_INFO)
                    return

                index = xbmcgui.Dialog().select("Vyber video k přehrání", dialog_items)
                if index == -1:
                    return
                selected = scored_candidates[index][2]
                try:
                    url = get_direct_link(token, selected["ident"])
                    xbmc.Player().play(url)
                except Exception as e:
                    xbmcgui.Dialog().notification("Chyba", str(e), xbmcgui.NOTIFICATION_ERROR)
                return


            best_result = scored_candidates[0][2]
            url = get_direct_link(token, best_result["ident"])
            xbmc.Player().play(url)
        except Exception as e:
            xbmcgui.Dialog().notification("Chyba", str(e), xbmcgui.NOTIFICATION_ERROR)

    else:
        show_main_menu(token)


def get_file_info(token, ident):
    data = urllib.parse.urlencode({
        "ident": ident,
        "maybe_removed": 1
    }).encode("utf-8")

    req = urllib.request.Request("https://webshare.cz/api/file_info/", data=data)
    req.add_header("User-Agent", "Mozilla/5.0")
    req.add_header("Cookie", f"session={token}")
    req.add_header("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8")

    with urllib.request.urlopen(req) as res:
        xml = res.read().decode("utf-8")
        root = ET.fromstring(xml)

    if root.findtext("status") != "OK":
        raise Exception("Nepodařilo se získat info o souboru.")

    return {
        "name": root.findtext("name"),
        "description": root.findtext("description"),
        "size": int(root.findtext("size") or 0),
        "type": root.findtext("type"),
        "positive_votes": root.findtext("positive_votes") or "0"
    }

if __name__ == "__main__":
    run()