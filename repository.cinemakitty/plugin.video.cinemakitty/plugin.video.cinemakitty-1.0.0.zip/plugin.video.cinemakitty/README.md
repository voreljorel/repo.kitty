# CinemaKitty

Doplněk pro Kodi, který umožňuje přehrávat filmy přímo z Webshare.cz (vyžaduje VIP účet).

## ✨ Funkce

- 🔐 Automatické přihlášení k Webshare API
- 🔍 Vyhledávání filmů podle názvu přes Webshare
- ▶️ Streamování přímých odkazů (pouze pro VIP uživatele)
- ❤️ Ukládání oblíbených filmů
- 🎬 Integrace s TMDb (filmová databáze)
  - Nejlépe hodnocené filmy
  - Právě v kinech
  - Populární filmy
  - Populární/nejlépe hodnocené seriály
  - Filmy podle žánrů
- 📺 Výběr kvality přehrávání (1080p, 720p, bez filtru)
- 🇨🇿 Plná lokalizace do češtiny

## 🛠️ Plánované funkce

- 🕓 Historie přehrávání
- 🧹 Správa oblíbených (mazání)
- 🧠 Inteligentní výběr nejlepšího souboru (podle kvality, velikosti, názvu)
- 📁 Podpora seriálů (sezóny, epizody)

## ⚙️ Požadavky

- Kodi 20+ (doplněk je psán pro Python 3)
- Aktivní VIP účet na Webshare.cz

## 📦 Instalace

1. Stáhni ZIP doplňku `plugin.video.cinemakitty.zip`
2. V Kodi přejdi do **Doplňky > Instalovat ze souboru ZIP**
3. Po instalaci otevři doplněk a nastav své přihlašovací údaje
4. Užij si streamování!

## 👨‍💻 Autor

David Kotek (VorelJorel)